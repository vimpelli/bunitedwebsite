<footer class="content-info" role="contentinfo">
<div class="container-fluid">
	<div class="row footer">
		<?php dynamic_sidebar('sidebar-footer'); ?>
	</div>
</div>
<!-- <div class="sub_footer">
	<p>Hola</p>
</div> -->
</footer>
