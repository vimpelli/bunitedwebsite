<?php

namespace OpenCloud\Common\Exceptions;

class AuthenticationError extends \Exception {}
