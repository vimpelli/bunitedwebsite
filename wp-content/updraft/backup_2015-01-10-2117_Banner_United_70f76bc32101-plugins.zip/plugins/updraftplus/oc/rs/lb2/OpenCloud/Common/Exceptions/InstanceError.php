<?php

namespace OpenCloud\Common\Exceptions;

class InstanceError extends \Exception {}
