<?php

namespace OpenCloud\Common\Exceptions;

class RecordTypeError extends \Exception {}
