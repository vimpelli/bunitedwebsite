<?php

namespace OpenCloud\Common\Exceptions;

class NetworkDeleteError extends \Exception {}
