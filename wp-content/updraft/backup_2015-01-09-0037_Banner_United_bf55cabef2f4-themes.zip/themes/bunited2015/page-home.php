<?php while (have_posts()) : the_post(); ?>

<!-- First Section -->
<?php if (get_field('headline')): ?>
<div class="section1">
  	<div class="headline_wrapper">
    	<h2 class="headline"><?php the_field('section_1');?></h2>
  	</div>
	<div class="container">
		<div class="col-xs-12 primary_content">
		 	<?php the_field('section_1_body');?>
		</div>
	</div>
</div>
<?php endif ?>

<!-- Second Section -->
<?php if (get_field('headline')): ?>
<div class="section2">
 	<div class="headline_wrapper">
    	<h2 class="headline"><?php the_field('section_2');?></h2>
 	</div>
	<div class="container">
		<div class="row">
			<div class="col-xs-12 primary_content">
			 	<?php the_field('section_2_body');?>
			</div>
		</div>
	</div>
</div>
<?php endif ?>

<!-- Third Section -->
<?php if (get_field('headline')): ?>
<div class="section3">
	<div class="headline_wrapper">
		<h2 class="headline"><?php the_field('section_3');?></h2>
	</div>
	<div class="container">
		<div class="col-xs-12 primary_content">
			<?php the_field('section_3_body');?>
		</div>
	</div>
</div>
<?php endif ?>
<?php endwhile; ?>
