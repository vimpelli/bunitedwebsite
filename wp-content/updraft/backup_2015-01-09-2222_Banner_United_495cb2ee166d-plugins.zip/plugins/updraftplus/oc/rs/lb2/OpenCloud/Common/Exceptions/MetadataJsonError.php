<?php

namespace OpenCloud\Common\Exceptions;

class MetadataJsonError extends \Exception {}
