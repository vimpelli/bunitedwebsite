<?php while (have_posts()) : the_post(); ?>
<div class="col-xs-12 primary_content">
 	<?php get_template_part('templates/content', 'page'); ?>
</div>

<!-- <div class="col-xs-12">
 	<?php dynamic_sidebar('sidebar-primary'); ?>
</div> -->

<?php endwhile; ?>
