<?php

namespace OpenCloud\Common\Exceptions;

class HttpTimeoutError extends \Exception {}
